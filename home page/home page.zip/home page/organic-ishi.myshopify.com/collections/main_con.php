<?php
          $con=mysqli_connect("localhost","root","");
          $db=mysqli_select_db($con,"market1");
          
        ?>